export const q = (cents: number) => `Q ${(cents/100).toFixed(2)}`;
