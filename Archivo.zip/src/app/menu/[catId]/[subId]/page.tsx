'use client';

import React, { useEffect, useMemo, useState } from 'react';

// ⬇️ Ajusta este import al path real de tu hook de carrito
//   He visto en tu layout que hay <CartProvider>. Si tu hook está en otro sitio
//   (p.ej. "@/hooks/useCart" o "@/context/CartContext"), cámbialo aquí:
import { useCart } from '@/context/CartContext'; // <-- AJUSTA SI ES NECESARIO

function getFirebaseClientConfig() {
  return {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY!,
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN!,
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID!,
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID!,
  };
}
async function ensureFirebaseApp() {
  const app = await import('firebase/app');
  if (!app.getApps().length) {
    const cfg = getFirebaseClientConfig();
    if (cfg.apiKey && cfg.authDomain && cfg.projectId && cfg.appId) {
      app.initializeApp(cfg);
    }
  }
}
async function getFirestoreMod() {
  await ensureFirebaseApp();
  return await import('firebase/firestore');
}

type Category = { id: string; name: string; isActive?: boolean; };
type Subcategory = { id: string; name: string; categoryId: string; isActive?: boolean; };
type Addon = { name: string; price: number };
type MenuItem = {
  id: string;
  name: string;
  description?: string;
  price: number;
  imageUrl?: string | null;
  active?: boolean;
  categoryId: string;
  subcategoryId: string;
  addons?: Addon[];
};

function fmtQ(n?: number) {
  if (typeof n !== 'number') return '—';
  try {
    return new Intl.NumberFormat('es-GT', { style: 'currency', currency: 'GTQ' }).format(n);
  } catch {
    return `Q ${Number(n).toFixed(2)}`;
  }
}

export default function MenuItemsPage({ params }: { params: { catId: string; subId: string }}) {
  const { catId, subId } = params;

  const [cat, setCat] = useState<Category | null>(null);
  const [subcat, setSubcat] = useState<Subcategory | null>(null);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  // selección de addons por itemId
  const [selected, setSelected] = useState<Record<string, Record<string, boolean>>>({}); // itemId -> addonName -> checked

  // carrito
  const cartApi = (() => {
    try { return useCart(); } catch { return {} as any; }
  })();
  const addToCartFn: (line: any) => void = (line) => {
    if (!cartApi) return;
    if (typeof cartApi.addLine === 'function') return cartApi.addLine(line);
    if (typeof cartApi.addItem === 'function') return cartApi.addItem(line);
    if (typeof cartApi.add === 'function') return cartApi.add(line);
    // fallback: guarda en localStorage por si tu contexto luego lo recoge
    try {
      const raw = window.localStorage.getItem('cart_fallback') || '[]';
      const arr = JSON.parse(raw);
      arr.push(line);
      window.localStorage.setItem('cart_fallback', JSON.stringify(arr));
      alert('Agregado al carrito.');
    } catch {}
  };

  useEffect(() => {
    let unsubCat: any, unsubSub: any, unsubItems: any;
    (async () => {
      try {
        setErr(null);
        const { getFirestore, doc, onSnapshot, collection, query, where } = await getFirestoreMod();
        const db = getFirestore();

        unsubCat = onSnapshot(doc(db, 'categories', catId), (snap) => {
          setCat(snap.exists() ? ({ id: snap.id, ...snap.data() } as any) : null);
        });

        unsubSub = onSnapshot(doc(db, 'subcategories', subId), (snap) => {
          setSubcat(snap.exists() ? ({ id: snap.id, ...snap.data() } as any) : null);
        });

        unsubItems = onSnapshot(
          query(collection(db, 'menuItems'),
            where('categoryId', '==', catId),
            where('subcategoryId', '==', subId)
          ),
          (snap) => {
            const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() } as any));
            const active = rows.filter((r) => r.active !== false);
            active.sort((a: any, b: any) => String(a?.name||'').localeCompare(String(b?.name||'')));
            setItems(active);
            setLoading(false);
          }
        );
      } catch (e: any) {
        setErr(e?.message || 'Error cargando platos');
        setLoading(false);
      }
    })();

    return () => {
      try { unsubCat && unsubCat(); } catch {}
      try { unsubSub && unsubSub(); } catch {}
      try { unsubItems && unsubItems(); } catch {}
    };
  }, [catId, subId]);

  const toggleAddon = (itemId: string, addonName: string) => {
    setSelected((prev) => {
      const byItem = prev[itemId] || {};
      return {
        ...prev,
        [itemId]: { ...byItem, [addonName]: !byItem[addonName] }
      };
    });
  };

  const calcUnitPrice = (mi: MenuItem, sel: Record<string, boolean>): number => {
    const base = Number(mi.price || 0) || 0;
    const add = (mi.addons || []).reduce((sum, a) => {
      if (sel && sel[a.name]) return sum + (Number(a.price) || 0);
      return sum;
    }, 0);
    return base + add;
  };

  const onAddToCart = (mi: MenuItem) => {
    const selMap = selected[mi.id] || {};
    const chosenAddons = (mi.addons || []).filter(a => selMap[a.name]);
    const unitPrice = calcUnitPrice(mi, selMap);

    const line = {
      // Lo que checkout ya sabe leer:
      id: mi.id,
      itemId: mi.id,
      name: mi.name,
      basePrice: Number(mi.price || 0) || 0,
      price: unitPrice,             // unitario con addons
      quantity: 1,
      addons: chosenAddons.map(a => ({ name: a.name, price: Number(a.price) || 0 })),

      // extra, por conveniencia:
      categoryId: mi.categoryId,
      subcategoryId: mi.subcategoryId,
      imageUrl: mi.imageUrl || null,
      // Puedes agregar aquí campos como notes o specialInstructions si tu checkout los usa.
    };

    addToCartFn(line);
  };

  if (loading) return <div className="container py-4">Cargando…</div>;
  if (err) return <div className="container py-4 text-danger">{err}</div>;
  if (!cat || !subcat) return <div className="container py-4">No encontrado.</div>;

  return (
    <div className="container py-4">
      <div className="d-flex align-items-center mb-3">
        <a href={`/menu/${catId}`} className="me-2 text-decoration-none">←</a>
        <h1 className="h5 m-0">{cat.name} — {subcat.name}</h1>
      </div>

      {items.length === 0 && <div className="text-muted">No hay platos en esta subcategoría.</div>}

      <div className="row g-3">
        {items.map((mi) => {
          const sel = selected[mi.id] || {};
          const unitPrice = calcUnitPrice(mi, sel);
          return (
            <div key={mi.id} className="col-12 col-md-6">
              <div className="card h-100">
                {mi.imageUrl ? (
                  <img src={mi.imageUrl} alt={mi.name} style={{ width: '100%', height: 180, objectFit: 'cover' }} />
                ) : null}
                <div className="card-body">
                  <div className="d-flex justify-content-between">
                    <div className="fw-semibold">{mi.name}</div>
                    <div className="fw-semibold">{fmtQ(mi.price)}</div>
                  </div>
                  {mi.description ? <div className="text-muted small mt-1">{mi.description}</div> : null}

                  {!!(mi.addons?.length) && (
                    <div className="mt-3">
                      <div className="fw-semibold small mb-1">Addons</div>
                      <div className="d-flex flex-column gap-1">
                        {mi.addons!.map((a) => (
                          <label key={a.name} className="form-check d-flex align-items-center">
                            <input
                              className="form-check-input me-2"
                              type="checkbox"
                              checked={!!sel[a.name]}
                              onChange={() => toggleAddon(mi.id, a.name)}
                            />
                            <span className="me-auto">{a.name}</span>
                            <span className="text-muted small">{fmtQ(a.price)}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <div className="card-footer d-flex justify-content-between align-items-center">
                  <div className="text-muted small">Total unitario: <span className="fw-semibold">{fmtQ(unitPrice)}</span></div>
                  <button className="btn btn-primary btn-sm" onClick={() => onAddToCart(mi)}>
                    Agregar al carrito
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 d-flex gap-2">
        <a className="btn btn-outline-secondary" href={`/menu/${catId}`}>Volver</a>
        <a className="btn btn-success" href="/checkout">Ir al checkout</a>
      </div>
    </div>
  );
}
