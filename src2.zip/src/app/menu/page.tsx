"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useCart } from "@/lib/cart/context";

// Utilidad simple para formatear a Quetzales
const q = (n: number) => `Q ${Number(n ?? 0).toFixed(2)}`;

type MenuItem = {
  id: string;
  title?: string;
  name?: string;
  description?: string;
  basePriceCents?: number; // preferido
  price?: number;          // fallback (unidades)
  imageUrl?: string;
  isActive?: boolean;
  isAvailable?: boolean;
};

type OptionGroup = {
  id: string;
  name: string;
  minSelect: number;
  maxSelect: number;
  sortOrder?: number;
};

type OptionItem = {
  id: string;
  name: string;
  priceDelta?: number;
  sortOrder?: number;
  isActive?: boolean;
};

// Helpers HTTP
async function getJSON<T = any>(url: string) {
  const res = await fetch(url, { cache: "no-store" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`);
  return data as T;
}

export default function MenuPage() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modal state
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<MenuItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [groups, setGroups] = useState<OptionGroup[]>([]);
  const [optionsByGroup, setOptionsByGroup] = useState<Record<string, OptionItem[]>>({});
  const [selected, setSelected] = useState<Record<string, string[]>>({});
  const [quoting, setQuoting] = useState(false);
  const [quoteTotal, setQuoteTotal] = useState<number | null>(null);

  const { add } = useCart();

  useEffect(() => {
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await getJSON<{ items: MenuItem[] }>("/api/menu-items?limit=200&onlyAvailable=1");
        setItems(data.items ?? []);
      } catch (e: any) {
        setError(e?.message ?? "Error al cargar el menú");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const visible = useMemo(
    () => items.filter(i => (i.isActive ?? true) && (i.isAvailable ?? true)),
    [items]
  );

  function priceToCents(m: MenuItem) {
    if (typeof m.basePriceCents === "number") return m.basePriceCents;
    if (typeof m.price === "number") return Math.round(m.price * 100);
    return 0;
  }

  // Abrir modal: carga grupos + opciones y preselecciona mínimos
  async function openPicker(item: MenuItem) {
    setActive(item);
    setQuantity(1);
    setQuoteTotal(null);
    setOptionsByGroup({});
    setSelected({});
    setOpen(true);

    try {
      // 1) grupos del item
      const gData = await getJSON<{ items: any[] }>(`/api/option-groups?menuItemId=${encodeURIComponent(item.id)}`);
      const groupsNorm: OptionGroup[] = (gData.items || []).map((g: any) => ({
        id: g.id,
        name: g.name,
        minSelect: Number(g.minSelect ?? 0),
        maxSelect: Number(g.maxSelect ?? 0),
        sortOrder: g.sortOrder ?? 0,
      })).sort((a,b)=>(a.sortOrder||0)-(b.sortOrder||0));
      setGroups(groupsNorm);

      // 2) cargar opciones por grupo
      const dict: Record<string, OptionItem[]> = {};
      for (const g of groupsNorm) {
        const oData = await getJSON<{ items: any[] }>(`/api/option-items?groupId=${encodeURIComponent(g.id)}`);
        dict[g.id] = (oData.items || [])
          .filter((o: any) => o.isActive !== false)
          .map((o: any) => ({
            id: o.id,
            name: o.name,
            priceDelta: Number(o.priceDelta ?? 0),
            sortOrder: o.sortOrder ?? 0,
            isActive: o.isActive !== false,
          }))
          .sort((a,b)=>(a.sortOrder||0)-(b.sortOrder||0));
      }
      setOptionsByGroup(dict);

      // 3) preseleccionar mínimos
      const pre: Record<string, string[]> = {};
      for (const g of groupsNorm) {
        const opts = dict[g.id] || [];
        if (g.minSelect >= 1 && opts.length > 0) {
          const need = g.maxSelect > 0 ? Math.min(g.minSelect, g.maxSelect) : g.minSelect;
          pre[g.id] = opts.slice(0, need).map(o => o.id);
        }
      }
      setSelected(pre);

      // 4) cotización inicial
      if (groupsNorm.length) {
        await doQuote(item, pre, 1);
      } else {
        // sin grupos: mostramos base
        setQuoteTotal(priceToCents(item) / 100);
      }
    } catch (e: any) {
      // si falla carga de grupos, no bloqueamos agregar sin opciones
      setGroups([]);
      setOptionsByGroup({});
      setQuoteTotal(priceToCents(item) / 100);
    }
  }

  function toggle(groupId: string, optionId: string, multi: boolean) {
    setSelected((prev) => {
      const cur = new Set(prev[groupId] || []);
      if (multi) {
        if (cur.has(optionId)) cur.delete(optionId);
        else cur.add(optionId);
        return { ...prev, [groupId]: Array.from(cur) };
      } else {
        return { ...prev, [groupId]: [optionId] };
      }
    });
  }

  // Validar min/max localmente
  function validateSelections(): string | null {
    for (const g of groups) {
      const sel = selected[g.id] || [];
      if (g.minSelect > 0 && sel.length < g.minSelect) {
        return `Debes elegir al menos ${g.minSelect} opción en "${g.name}".`;
      }
      if (g.maxSelect > 0 && sel.length > g.maxSelect) {
        return `Has elegido más de ${g.maxSelect} opciones en "${g.name}".`;
      }
    }
    return null;
  }

  async function doQuote(item: MenuItem, selMap: Record<string,string[]>, qty: number) {
    try {
      setQuoting(true);
      const payload = {
        items: [{
          menuItemId: item.id,
          quantity: Math.max(1, qty),
          options: Object.entries(selMap)
            .filter(([,arr]) => arr && arr.length)
            .map(([groupId, optionItemIds]) => ({ groupId, optionItemIds })),
        }],
        tipAmount: 0,
      };
      const res = await fetch("/api/cart/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (res.ok) {
        // Mostramos total por línea (o el total general / qty)
        const total = Number(data?.total ?? 0);
        setQuoteTotal(total);
      } else {
        // si falla la cotización, no bloqueamos la UI
        setQuoteTotal(null);
      }
    } catch {
      setQuoteTotal(null);
    } finally {
      setQuoting(false);
    }
  }

  async function confirmAdd() {
    if (!active) return;
    const err = validateSelections();
    if (err) { alert(err); return; }

    // Agregar al carrito con selecciones
    const selections = Object.entries(selected)
      .filter(([,arr]) => arr && arr.length)
      .map(([groupId, optionItemIds]) => ({ groupId, optionItemIds }));

    const name = active.title ?? active.name ?? "Item";
    add({
      menuItemId: active.id,
      menuItemName: name,
      quantity: Math.max(1, quantity),
      selections,
    });
    setOpen(false);
  }

  return (
    <div className="container py-4">
      <h1 className="mb-3">Menú</h1>

      {loading && <p>Cargando…</p>}
      {error && <p className="text-danger">{error}</p>}

      {!loading && !error && (
        <>
          <div className="row g-3">
            {visible.map((m) => {
              const title = m.title ?? m.name ?? "Item";
              const priceCents = priceToCents(m);
              return (
                <div key={m.id} className="col-12 col-md-6 col-lg-4">
                  <div className="card h-100 shadow-sm">
                    {m.imageUrl && (
                      <img src={m.imageUrl} className="card-img-top" alt={title} />
                    )}
                    <div className="card-body d-flex flex-column">
                      <h5 className="card-title">{title}</h5>
                      {m.description && (
                        <p className="card-text flex-grow-1">{m.description}</p>
                      )}
                      <div className="d-flex justify-content-between align-items-center">
                        <strong>{q(priceCents / 100)}</strong>
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => openPicker(m)}
                        >
                          Agregar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            {visible.length === 0 && (
              <div className="col-12">
                <p>No hay platos disponibles por ahora.</p>
              </div>
            )}
          </div>

          <div className="mt-4">
            <Link href="/checkout" className="btn btn-success">
              Ir a checkout
            </Link>
          </div>
        </>
      )}

      {/* Modal simple (sin JS de Bootstrap, solo estilos) */}
      {open && active && (
        <div className="modal fade show" style={{ display: "block", background: "rgba(0,0,0,.5)" }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  {active.title ?? active.name} — Opciones
                </h5>
                <button className="btn-close" onClick={() => setOpen(false)} />
              </div>
              <div className="modal-body">
                {groups.length === 0 ? (
                  <div className="alert alert-secondary">
                    Este plato no tiene opciones configuradas.
                  </div>
                ) : (
                  <div className="vstack gap-3">
                    {groups.map((g) => {
                      const opts = optionsByGroup[g.id] || [];
                      const multi = !(
                        g.minSelect === 1 && g.maxSelect === 1
                      );
                      return (
                        <div key={g.id} className="border rounded p-3">
                          <div className="fw-semibold">
                            {g.name}{" "}
                            <span className="text-muted small">
                              {g.minSelect > 0 ? `min ${g.minSelect}` : "min 0"}
                              {g.maxSelect ? ` • max ${g.maxSelect}` : ""}
                            </span>
                          </div>
                          <div className="mt-2 vstack gap-2">
                            {opts.length ? (
                              opts.map((o) => {
                                const checked = (selected[g.id] || []).includes(o.id);
                                return (
                                  <label key={o.id} className="d-flex align-items-center gap-2 small">
                                    <input
                                      type={multi ? "checkbox" : "radio"}
                                      name={`g-${g.id}`}
                                      checked={checked}
                                      onChange={() => {
                                        toggle(g.id, o.id, multi);
                                        // re-cotiza rápido
                                        const next = {
                                          ...selected,
                                          [g.id]: multi
                                            ? (checked
                                                ? (selected[g.id] || []).filter(x => x !== o.id)
                                                : [...(selected[g.id] || []), o.id])
                                            : [o.id]
                                        };
                                        doQuote(active, next, quantity);
                                      }}
                                    />
                                    <span>
                                      {o.name}
                                      {o.priceDelta ? (
                                        <span className="text-muted"> (+{q(o.priceDelta)})</span>
                                      ) : null}
                                    </span>
                                  </label>
                                );
                              })
                            ) : (
                              <div className="text-muted small">
                                (sin opciones disponibles)
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="mt-3 d-flex align-items-center gap-2">
                  <label className="form-label m-0">Cantidad:</label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    style={{ width: 120 }}
                    value={quantity}
                    onChange={(e) => {
                      const qn = Math.max(1, Number(e.target.value || 1));
                      setQuantity(qn);
                      doQuote(active, selected, qn);
                    }}
                  />
                  <div className="ms-auto">
                    {quoting ? (
                      <span className="text-muted">Cotizando…</span>
                    ) : quoteTotal != null ? (
                      <span className="fw-semibold">
                        Estimado: {q(quoteTotal)}
                      </span>
                    ) : null}
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-outline-secondary" onClick={() => setOpen(false)}>
                  Cancelar
                </button>
                <button className="btn btn-primary" onClick={confirmAdd}>
                  Agregar al carrito
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
